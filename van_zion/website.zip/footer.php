<div class = "footer" ><img src="./uploads/icons/footer_logo_hd.png" width="161" height="50"></div>


 